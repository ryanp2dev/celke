<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8" />
    <link rel="shortcut icon" href="images/favicon.ico" />
    <title>Celke - DO ... While</title>
</head>

<body>
    <?php

    $a = 1;

    do {
        echo "E-mail enviado: $a <br>";
        $a++;
    } while ($a <= 10);

    ?>
</body>

</html>