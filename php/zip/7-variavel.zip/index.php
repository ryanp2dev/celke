<?php

$idade = 35;
$nome = "Cesar Szpak";

echo "O aluno $nome tem " . $idade . " anos";