<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8" />
    <link rel="shortcut icon" href="images/favicon.ico" />
    <title>Celke - While</title>
</head>

<body>
    <?php
    
    $a = 1;

    //O while é o comando repetição
    while($a <= 10){
        echo "Cadastro: $a <br>";

        //Incrementar a condição utilizada no while
        $a++;
    }

    ?>
</body>

</html>