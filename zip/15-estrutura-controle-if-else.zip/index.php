<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8" />
    <link rel="shortcut icon" href="images/favicon.ico" />
    <title>Celke - Estrutura de Controle - IF ... ELSE</title>
</head>

<body>
    <?php
    
    $a = 3;

    if($a == 2){
        echo "Depositar dinheiro. <br>";
    } else {
        echo "Opção não encontrada! <br>";
    }
    

    ?>
</body>

</html>